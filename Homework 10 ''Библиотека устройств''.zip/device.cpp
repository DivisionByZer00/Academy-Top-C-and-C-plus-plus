#include "device.h"
#include <iostream>

void printDevice(const Device& device)
{
    std::cout << device.name << ": " << device.battery << "%\n";
}

bool isBatteryValid(const Device& device)
{
    return device.battery >= 0 && device.battery <= 100;
}

void chargeDevice(Device& device, int bonus) {
    device.battery += bonus;

}