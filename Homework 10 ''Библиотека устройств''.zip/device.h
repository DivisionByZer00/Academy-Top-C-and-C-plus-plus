#ifndef DEVICE_H
#define DEVICE_H

#include <string>

struct Device
{
    std::string name;
    int battery;
};

void printDevice(const Device& device);
bool isBatteryValid(const Device& device);


void chargeDevice(Device&, int bonus);

#endif