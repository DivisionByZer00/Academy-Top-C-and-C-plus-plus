#include "device.h"
#include <iostream>
#include <string>

int main()
{
    Device device{};
    int bonus{ 0 };

    std::cout << "Name: ";
    std::getline(std::cin, device.name);

    std::cout << "Battery: ";
    std::cin >> device.battery;

    std::cout << "Bonus (0-20): ";
    std::cin >> bonus;



    if (device.name.empty()) {
        std::cout << "Input error\n";
        return 1;
    }

    if (!isBatteryValid(device)) {
        std::cout << "Input error\n";
        return 1;
    }

    if (bonus < 0 || bonus > 20) {
        std::cout << "Input error\n";
        return 1;
    }


    chargeDevice(device, bonus);


    if (!isBatteryValid(device)) {
        std::cout << "Input error\n";
        return 1;
    }


    printDevice(device);
    return 0;
}